import{a4 as s}from"./index-f3e5e52b.js";const t=Symbol(),o=()=>s(t,null);export{t as T,o as u};
