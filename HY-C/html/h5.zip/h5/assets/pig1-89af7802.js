const i=""+new URL("pig1-33798a3f.gif",import.meta.url).href;export{i};
