const o=""+new URL("blog-toc-b1356ac6.svg",import.meta.url).href;export{o as b};
