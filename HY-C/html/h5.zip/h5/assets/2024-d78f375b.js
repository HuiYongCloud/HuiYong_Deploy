const s=""+new URL("2024-716f8097.svg",import.meta.url).href;export{s};
