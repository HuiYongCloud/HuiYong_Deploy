const o=""+new URL("../logo.svg",import.meta.url).href;export{o as _};
