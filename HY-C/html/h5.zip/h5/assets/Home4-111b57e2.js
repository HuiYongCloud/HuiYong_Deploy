import{d as t,i as o,_ as s,r as _,o as a,c,b as i,h as r,f as d}from"./index-f3e5e52b.js";import{_ as p}from"./_plugin-vue_export-helper-c27b6911.js";const l={class:"flex-center-center",style:{width:"100vw",padding:"50px 0"}},m={class:"home4-group"},u=t({__name:"Home4",setup(h){const e=o(()=>s(()=>import("./MDPreview-2eafe59b.js"),["./MDPreview-2eafe59b.js","./index-f3e5e52b.js","./index-36e12fe0.css","./index-6cbc8a5f.js","./_commonjsHelpers-042e6b4d.js","./aria-4cb57325.js","./index-f1c05b61.js","./plugin-vue_export-helper-1cff8a04.js","./typescript-defaf979.js","./MDPreview-c455c19d.css"],import.meta.url)),n=_({content:`### 服务器配置 
| 类型 | CPU | 内存 | 网络 | 
| - | - | - | - | 
| 腾迅轻量 | 4核 | 4GB | 8M | 
| 腾迅轻量 | 2核 | 4GB | 5M | 
| ECS服务器 | 2核 | 2GB | 3M |
<div style='margin-top: 50px;' />

### 🎨 演示账号 
|名称 | 地址 | 
|---|---| 
|管理后台 | [admin.huiyong.online](https://admin.huiyong.online)| 
|客户端 | [huiyong.online](https://huiyong.online) | 
|账号 | test | 
|密码 | test123 | 
`});return(v,f)=>(a(),c("div",l,[i("div",m,[r(d(e),{content:n.content},null,8,["content"])])]))}});const x=p(u,[["__scopeId","data-v-51c42762"]]);export{x as default};
