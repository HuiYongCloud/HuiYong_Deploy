import{a4 as s}from"./index-5b3752b6.js";const t=Symbol(),o=()=>s(t,null);export{t as T,o as u};
