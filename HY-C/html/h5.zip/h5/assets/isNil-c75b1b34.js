function n(i){return i==null}export{n as i};
