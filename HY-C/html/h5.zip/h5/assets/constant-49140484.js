const s="van-hairline",o=`${s}--top`,t=`${s}--left`,a=`${s}--surround`,n=`${s}--top-bottom`,R="van-haptics-feedback",O=Symbol("van-form"),c=5;export{a as B,O as F,R as H,c as T,t as a,o as b,n as c};
