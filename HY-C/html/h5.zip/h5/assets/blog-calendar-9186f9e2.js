const a=""+new URL("blog-calendar-69e89f4a.svg",import.meta.url).href;export{a as b};
