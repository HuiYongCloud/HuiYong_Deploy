window.HuiYongConfig = {
    domain: "huiyong.online"
}