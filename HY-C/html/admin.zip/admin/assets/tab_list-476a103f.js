const s="/assets/tab_mind-661f004b.svg",a="/assets/tab_list-d9f8e77e.svg";export{s as T,a};
