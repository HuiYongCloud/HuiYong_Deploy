const s="/assets/404-e2f3d91a.png";export{s as i};
