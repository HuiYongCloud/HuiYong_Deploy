# aes.min.js

Source: rollups/aes.js from https://storage.googleapis.com/google-code-archive-downloads/v2/code.google.com/crypto-js/CryptoJS%20v3.1.2.zip
See https://code.google.com/archive/p/crypto-js/downloads

Note: This is not affected by https://github.com/jgraph/drawio-dev/security/dependabot/148 as the code does not use Math.random().
